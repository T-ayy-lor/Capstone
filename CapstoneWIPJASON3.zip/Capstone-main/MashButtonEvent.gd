extends Node2D

var jump_count: int = 0
var required_jumps: int = 20
var event_active: bool = false
var player = null
var event_completed: bool = false
var saved_position: Vector2
onready var mash_label: Label = get_node("../HUD/MashLabel")
# Called when the node enters the scene tree for the first time.
func _ready():
	mash_label.visible = false


# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass


func _on_Trigger_body_entered(body):
	if body.name == "Player" and not event_completed:
		player = body
		saved_position = body.position
		event_active = true
		body.event_mode = true
		mash_label.visible = true
		print("Player entered the mash button event!")

func _process(delta: float) -> void:
	if event_active:
		if Input.is_action_just_pressed("jump"):
			jump_count += 1
			mash_label.text = "MASH SPACE! " + str(jump_count) + "/20"
			print("Jump presses: ", jump_count)

			if jump_count >= required_jumps:
				event_active = false
				player.event_mode = false
				event_completed = true
				player.position = saved_position
				print("Mash event complete!")
